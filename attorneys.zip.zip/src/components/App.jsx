import React from 'react';

function App() {
  return (
    <div className="container my-5">
      <h2>Our Services</h2>
      <p>Explore our comprehensive legal solutions tailored to your needs.</p>
    </div>
  );
}

export default App;